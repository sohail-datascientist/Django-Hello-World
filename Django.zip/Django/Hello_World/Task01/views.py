from django.shortcuts import render, HttpResponse

# Create your views here.

def Task_1(request):
	return HttpResponse("Hello The World of Aleins")